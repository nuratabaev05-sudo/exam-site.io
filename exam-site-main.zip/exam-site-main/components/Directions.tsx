
import React, { useState } from 'react';
import { Direction } from '../types';

const DIRECTIONS: Direction[] = [
  {
    id: 'frontend',
    title: 'Frontend Developer',
    shortDesc: 'Создание интерфейсов и визуальной части сайтов.',
    fullDesc: 'Разработчик, который отвечает за внешний вид сайта или приложения. Он превращает дизайн-макеты в живой, интерактивный код, с которым взаимодействует пользователь.',
    color: 'from-blue-500 to-cyan-400',
    technologies: ['HTML/CSS', 'JavaScript', 'React', 'TypeScript', 'Tailwind'],
    icon: <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
  },
  {
    id: 'backend',
    title: 'Backend Developer',
    shortDesc: 'Работа с серверной логикой и базами данных.',
    fullDesc: 'Мозг любого приложения. Бэкенд-разработчик занимается хранением данных, безопасностью и логикой работы приложения "под капотом".',
    color: 'from-indigo-500 to-purple-400',
    technologies: ['Node.js', 'Python', 'PostgreSQL', 'Docker', 'Go'],
    icon: <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" /></svg>
  },
  {
    id: 'mobile',
    title: 'Mobile Developer',
    shortDesc: 'Разработка приложений для iOS и Android.',
    fullDesc: 'Специалист по созданию мобильного софта. Это может быть как нативная разработка (Swift/Kotlin), так и кроссплатформенная (React Native/Flutter).',
    color: 'from-emerald-500 to-teal-400',
    technologies: ['Swift', 'Kotlin', 'React Native', 'Flutter', 'Dart'],
    icon: <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
  },
  {
    id: 'data',
    title: 'Data Scientist',
    shortDesc: 'Анализ данных и искусственный интеллект.',
    fullDesc: 'Работа с большими данными, построение математических моделей и обучение нейросетей для прогнозирования и автоматизации процессов.',
    color: 'from-orange-500 to-rose-400',
    technologies: ['Python', 'Pandas', 'PyTorch', 'SQL', 'Scikit-learn'],
    icon: <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
  }
];

const Directions: React.FC = () => {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  return (
    <div className="container mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold mb-4">Направления разработки</h2>
        <p className="text-slate-400">Выберите карточку, чтобы узнать больше подробностей о профессии</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {DIRECTIONS.map((dir) => (
          <div 
            key={dir.id}
            onClick={() => setSelectedId(selectedId === dir.id ? null : dir.id)}
            className={`cursor-pointer group relative p-8 rounded-3xl transition-all duration-500 h-full flex flex-col ${selectedId === dir.id ? 'bg-slate-800 ring-2 ring-blue-500/50 scale-[1.02]' : 'bg-slate-900 hover:bg-slate-800'}`}
          >
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${dir.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
              <div className="text-white">
                {dir.icon}
              </div>
            </div>
            <h3 className="text-xl font-bold mb-3">{dir.title}</h3>
            <p className={`text-slate-400 text-sm transition-all duration-300 ${selectedId === dir.id ? 'opacity-0 h-0 overflow-hidden' : 'opacity-100'}`}>
              {dir.shortDesc}
            </p>
            
            <div className={`transition-all duration-500 ease-in-out ${selectedId === dir.id ? 'max-h-[500px] opacity-100 mt-2' : 'max-h-0 opacity-0 overflow-hidden'}`}>
              <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                {dir.fullDesc}
              </p>
              <div className="flex flex-wrap gap-2">
                {dir.technologies.map(tech => (
                  <span key={tech} className="px-3 py-1 bg-slate-700 text-xs rounded-full text-blue-300">
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-auto pt-6 flex justify-between items-center">
               <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest">
                 {selectedId === dir.id ? 'Свернуть' : 'Подробнее'}
               </span>
               <svg 
                className={`w-5 h-5 text-slate-500 transition-transform duration-300 ${selectedId === dir.id ? 'rotate-180' : ''}`} 
                fill="none" stroke="currentColor" viewBox="0 0 24 24"
               >
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
               </svg>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Directions;
