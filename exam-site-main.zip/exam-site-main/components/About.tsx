
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="relative group">
          <div className="absolute inset-0 bg-blue-500/10 rounded-3xl blur-2xl group-hover:bg-blue-500/20 transition-all duration-500"></div>
          <img 
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80" 
            alt="IT Specialist" 
            className="relative rounded-3xl shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
          />
        </div>
        <div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Почему выбирают <span className="text-blue-400">IT?</span></h2>
          <div className="space-y-6 text-slate-400 leading-relaxed">
            <p>
              Информационные технологии — это самая динамично развивающаяся отрасль в мире. Работая в этой сфере, вы получаете не только востребованную профессию, но и возможность постоянного роста.
            </p>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <span className="mt-1 p-1 bg-blue-500/20 text-blue-400 rounded-lg">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                </span>
                <span>Высокая востребованность на рынке труда и достойная оплата.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-1 p-1 bg-emerald-500/20 text-emerald-400 rounded-lg">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                </span>
                <span>Возможность удаленной работы из любой точки мира.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-1 p-1 bg-indigo-500/20 text-indigo-400 rounded-lg">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                </span>
                <span>Творчество в решении сложных технических задач.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
