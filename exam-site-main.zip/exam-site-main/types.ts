// Added React import to provide access to the React namespace for types
import React from 'react';

export interface Direction {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  icon: React.ReactNode;
  color: string;
  technologies: string[];
}